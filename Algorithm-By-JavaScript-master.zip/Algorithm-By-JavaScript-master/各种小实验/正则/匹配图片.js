var str='[https://happy.com/img/like.png](https://happy.com/img/like.png)'
var reg=/\.(png|jpg)$/