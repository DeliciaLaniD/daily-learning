export default function FixedButton() {
  return (
    <div className='fixed-container'>
      我是底部Bar
    </div>
  )
}