import App from "./App.js";
import { createApp } from "./core/index.js";

createApp(App).mount(document.querySelector("#app"));
