it('markdown transfrer', () => {
    const { tranHtml } = require('../index')

//     expect(tranHtml(__dirname + '/test.md', __dirname + '/test.css')).toBe(
// `<h1 id=\"t1\">T1</h1>
// <style>body{
//     margin: 0 auto;
// }</style>
// `)

})