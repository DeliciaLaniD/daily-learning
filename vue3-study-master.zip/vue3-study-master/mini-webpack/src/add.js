

import { minus } from "./minus.js";
console.log("minus:", minus(20, 1));
import { c } from "./c.js";
console.log("c:", c);

export default (a, b) => a + b;
