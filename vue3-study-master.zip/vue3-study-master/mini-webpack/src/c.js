export const c = 888;
