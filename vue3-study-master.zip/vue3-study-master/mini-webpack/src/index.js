// index.js
import add from "./add.js";
console.log(add(1, 2));




import { minus } from "./minus.js";

const sum = add(1, 2);
const division = minus(2, 1)

console.log(division);
