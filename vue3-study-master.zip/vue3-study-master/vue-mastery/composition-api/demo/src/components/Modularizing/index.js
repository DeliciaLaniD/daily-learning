import Modularzing from './Modularzing.vue'
export default Modularzing