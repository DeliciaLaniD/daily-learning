import SharingState from './SharingState.vue'
export default SharingState