import Suspense from './Suspense.vue'
export default Suspense