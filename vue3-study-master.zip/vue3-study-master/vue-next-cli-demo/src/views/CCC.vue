<template>
  <div class="hello" style="border: 1px solid">
    CCC
  </div>
</template>
<script>
export default {
  
};
</script>