export default {
  getProducts: () => {
    return {
      name: "product01",
    };
  },
};
