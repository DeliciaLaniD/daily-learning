import str from './moduleA'
console.log('babel ok')
console.log('ModuelA ' + str) 

import { expect } from "chai";

describe("mutations", () => {
    it("INCREMENT", () => {
      expect(1).to.equal(1);
    });
  });