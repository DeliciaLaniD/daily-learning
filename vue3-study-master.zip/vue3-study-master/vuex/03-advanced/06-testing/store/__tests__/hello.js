// export default {
//     str: 'abc'
// }

export const a = 10

// module.exports = {
//   str: "abc",
// };
