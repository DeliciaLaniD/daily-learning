
import mutations from './mutations.spec'
import getters from './getters.spec'
import actions from './actions.spec.js'