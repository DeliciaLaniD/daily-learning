<script>
import State from "./components/State.js";
import HelloWorld from "./components/HelloWorld.js";
import Getter from "./components/Getter.js";
import Mutation from "./components/Mutation.js";
import { h } from "vue/dist/vue.esm-bundler";
export default {
  name: "App",
  components: {},
  render() {
    // return h(HelloWorld);
    // return h(State);
    // return h(Getter);
    //  return h(Mutation);

  },
};
</script>

