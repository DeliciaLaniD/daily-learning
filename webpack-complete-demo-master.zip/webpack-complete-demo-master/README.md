# webpack-complete-demo
常用webpack配置 | 构建优化

多页面打包通用配置在 `mpa-build` 分支  
dllPlugin配置在 `dll-plugin` 分支  

配套文章：[webpack实践总结 | 优化方案](https://juejin.im/post/6880487034130169869)