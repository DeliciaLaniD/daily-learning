import {hello, cat} from './helloworld';
// import('./hello2')
import {$} from 'jquery'
import './style.less'
new cat('mimi7')
console.log($)

document.write(hello());